package com.example.loginmvvm.login.base

import androidx.lifecycle.ViewModel
import org.koin.core.KoinComponent

abstract class BaseVM : ViewModel(), KoinComponent