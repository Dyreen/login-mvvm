package com.example.loginmvvm.login.model.remote.request

/*
 * Created by Birju Vachhani on 18 November 2019
 * Copyright © 2019 Login MVVM. All rights reserved.
 */

data class LoginRequest(val email: String, val password: String)