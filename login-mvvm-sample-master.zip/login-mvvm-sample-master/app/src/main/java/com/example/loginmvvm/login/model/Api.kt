package com.example.loginmvvm.login.model

/*
 * Created by Birju Vachhani on 18 November 2019
 * Copyright © 2019 Login MVVM. All rights reserved.
 */

object Api {
    const val BASE_URL = "http://192.168.43.173:8080/"
    const val LOGIN_PATH = "login"
}