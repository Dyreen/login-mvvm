package com.example.loginmvvm.login.model.remote.error

/*
 * Created by Birju Vachhani on 18 November 2019
 * Copyright © 2019 Login MVVM. All rights reserved.
 */

data class LoginError(val error: String, val success: Boolean = false)