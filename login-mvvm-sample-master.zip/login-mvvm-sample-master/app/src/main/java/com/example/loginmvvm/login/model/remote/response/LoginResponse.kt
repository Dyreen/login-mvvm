package com.example.loginmvvm.login.model.remote.response

/*
 * Created by Birju Vachhani on 18 November 2019
 * Copyright © 2019 Login MVVM. All rights reserved.
 */

data class LoginResponse(val success: Boolean, val token: String)